import type { Language, ToolType } from '../types';

export interface SampleMessage {
  id: string;
  label: Record<Language, string>;
  content: Record<Language, string>;
}

export const SAMPLE_MESSAGES: Record<ToolType, SampleMessage[]> = {
  scam: [
    {
      id: 'scam-scholarship',
      label: {
        en: 'Fake Sindh Laptop / Scholarship Scam',
        ur: 'جعلی اسکالرشپ اور ایزی پیسہ فراڈ',
        sd: 'جعلي اسڪالرشپ ۽ ايزي پيسا فراڊ',
      },
      content: {
        en: 'CONGRATULATIONS! You are selected for Sindh Student Free Laptop & Rs. 35,000 Scholarship. Urgent: Send Rs. 1,500 registration fee via Easypaisa and reply with your 4-digit OTP code within 2 hours or your seat will be cancelled.',
        ur: 'مبارک ہو! آپ سندھ اسٹوڈنٹ مفت لیپ ٹاپ اور 35,000 روپے اسکالرشپ کے لیے منتخب ہو گئے ہیں۔ فوری طور پر ایزی پیسہ کے ذریعے 1500 روپے فیس بھیجیں اور 2 گھنٹے میں اپنا او ٹی پی کوڈ بتائیں ورنہ داخلہ منسوخ ہو جائے گا۔',
        sd: 'مبارڪ هجي! توهان سنڌ اسٽوڊنٽ مفت ليپ ٽاپ ۽ 35,000 رپيا اسڪالرشپ لاءِ چونڊيا ويا آهيو. فوري طور ايزي پيسا ذريعي 1500 رپيا رجسٽريشن فيس موڪليو ۽ پنهنجو 4 هندسن وارو او ٽي پي ڪوڊ ٻڌايو نه ته سيٽ رد ٿي ويندي.',
      },
    },
    {
      id: 'scam-wallet',
      label: {
        en: 'JazzCash / Bank Account Block Threat',
        ur: 'بینک اکاؤنٹ بلاک ہونے کی دھمکی',
        sd: 'بئنڪ اڪائونٽ بلاڪ ٿيڻ جي ڌمڪي',
      },
      content: {
        en: 'URGENT ALERT: Your JazzCash & Student Bank account will be blocked today by PTA. Verify now by calling 0300-0000000 and sharing your MPIN and CNIC code immediately.',
        ur: 'فوری الرٹ: آپ کا جاز کیش اور اسٹوڈنٹ بینک اکاؤنٹ آج بند کر دیا جائے گا۔ فوری تصدیق کے لیے اپنا MPIN اور او ٹی پی کوڈ شیئر کریں۔',
        sd: 'فوري الرٽ: توهان جو جاز ڪيش ۽ اسٽوڊنٽ بئنڪ اڪائونٽ اڄ بند ڪيو ويندو. فوري تصديق لاءِ پنهنجو MPIN ۽ او ٽي پي ڪوڊ شيئر ڪريو.',
      },
    },
    {
      id: 'scam-safe',
      label: {
        en: 'Safe University Official Notice',
        ur: 'محفوظ یونیورسٹی سرکاری نوٹس',
        sd: 'محفوظ يونيورسٽي سرڪاري نوٽيس',
      },
      content: {
        en: 'Reminder from University Examination Branch: Mid-term timetable has been uploaded to the official portal at https://muet.edu.pk. Please check your roll number slip on the university website.',
        ur: 'یونیورسٹی امتحانی برانچ کی طرف سے اطلاع: مڈ ٹرم ٹائم ٹیبل سرکاری ویب سائٹ https://muet.edu.pk پر اپ لوڈ کر دیا گیا ہے۔ براہ کرم ویب سائٹ سے اپنی رول نمبر سلپ چیک کریں۔',
        sd: 'يونيورسٽي امتحاني برانچ پاران اطلاع: مڊ ٽرم ٽائيم ٽيبل سرڪاري ويب سائيٽ https://muet.edu.pk تي اپ لوڊ ڪيو ويو آهي. مهرباني ڪري ويب سائيٽ تان پنهنجي رول نمبر سلپ چيڪ ڪريو.',
      },
    },
  ],
  link: [
    {
      id: 'link-phishing',
      label: {
        en: 'Phishing Scholarship Claim Link',
        ur: 'جعلی اسکالرشپ فشنگ لنک',
        sd: 'جعلي اسڪالرشپ فشنگ لنڪ',
      },
      content: {
        en: 'http://hec-sindh-scholarship-claim.xyz/verify-otp-login',
        ur: 'http://hec-sindh-scholarship-claim.xyz/verify-otp-login',
        sd: 'http://hec-sindh-scholarship-claim.xyz/verify-otp-login',
      },
    },
    {
      id: 'link-shortener',
      label: {
        en: 'Hidden Shortened Prize Link',
        ur: 'مخفی مختصر انعامی لنک',
        sd: 'لڪيل مختصر انعامي لنڪ',
      },
      content: {
        en: 'https://bit.ly/free-student-grant-claim-2026',
        ur: 'https://bit.ly/free-student-grant-claim-2026',
        sd: 'https://bit.ly/free-student-grant-claim-2026',
      },
    },
    {
      id: 'link-official',
      label: {
        en: 'Official Sindh / HEC Portal',
        ur: 'سرکاری تعلیمی پورٹل لنک',
        sd: 'سرڪاري تعليمي پورٽل لنڪ',
      },
      content: {
        en: 'https://hec.gov.pk/english/scholarshipsgrants/Pages/default.aspx',
        ur: 'https://hec.gov.pk/english/scholarshipsgrants/Pages/default.aspx',
        sd: 'https://hec.gov.pk/english/scholarshipsgrants/Pages/default.aspx',
      },
    },
  ],
  cyberbullying: [
    {
      id: 'bully-blackmail',
      label: {
        en: 'Extortion & Threat to Leak Photos',
        ur: 'تصاویر وائرل کرنے کی بلیک میلنگ',
        sd: 'تصويرون وائرل ڪرڻ جي بليڪ ميلنگ',
      },
      content: {
        en: 'Send me Rs. 10,000 by tonight or I will leak your edited photos to your entire university WhatsApp group and ruin your reputation.',
        ur: 'آج رات تک 10,000 روپے بھیجو ورنہ میں تمہاری تصاویر پورے یونیورسٹی واٹس ایپ گروپ میں وائرل کر کے تمہیں بدنام کر دوں گا۔',
        sd: 'اڄ رات تائين 10,000 رپيا موڪل نه ته مان تنهنجون تصويرون سڄي يونيورسٽي واٽس ايپ گروپ ۾ وائرل ڪري تنهنجي عزت خراب ڪري ڇڏيندس.',
      },
    },
    {
      id: 'bully-insult',
      label: {
        en: 'Targeted Verbal Harassment',
        ur: 'آن لائن تضحیک اور بدسلوکی',
        sd: 'آن لائين توهين ۽ بدسلوڪي',
      },
      content: {
        en: 'You are such a worthless loser, nobody in class wants you around. Stop posting online, everyone is laughing at you!',
        ur: 'تم بالکل بے وقوف اور ناکارہ ہو، کلاس میں کوئی تمہیں پسند نہیں کرتا۔ پوسٹ کرنا بند کرو، سب تم پر ہنس رہے ہیں!',
        sd: 'تون بلڪل بيوقوف ۽ ناڪاره آهين، ڪلاس ۾ ڪو به توکي پسند نٿو ڪري. پوسٽ ڪرڻ بند ڪر، سڀ توتي کلن پيا!',
      },
    },
    {
      id: 'bully-safe',
      label: {
        en: 'Respectful Classmate Message',
        ur: 'مہذب ہم جماعت کا پیغام',
        sd: 'مهذب هم ڪلاس جو پيغام',
      },
      content: {
        en: 'Assalam-o-Alaikum, could you please share the physics lab notes from today? Thank you so much for your help!',
        ur: 'السلام علیکم، کیا آپ آج کے فزکس لیب نوٹس شیئر کر سکتے ہیں؟ آپ کی مدد کا بہت شکریہ!',
        sd: 'اسلام عليڪم، ڇا توهان اڄ جا فزڪس ليب نوٽس شيئر ڪري سگهو ٿا؟ توهان جي مدد لاءِ وڏي مهرباني!',
      },
    },
  ],
};

export interface SafetyTipItem {
  id: string;
  category: 'scam' | 'links' | 'bullying' | 'portals';
  title: Record<Language, string>;
  detail: Record<Language, string>;
  action: Record<Language, string>;
}

export const SAFETY_TIPS: SafetyTipItem[] = [
  {
    id: 'tip-otp',
    category: 'scam',
    title: {
      en: 'Never Share OTPs, MPINs, or Passwords',
      ur: 'او ٹی پی، ایم پن یا پاس ورڈ کبھی شیئر نہ کریں',
      sd: 'او ٽي پي، ايم پن يا پاسورڊ ڪڏهن به شيئر نه ڪريو',
    },
    detail: {
      en: 'Scammers often pretend to be Easypaisa, JazzCash, bank staff, or university officials asking for a 4-digit or 6-digit code to "verify" your account or send scholarship money.',
      ur: 'فراڈیے اکثر ایزی پیسہ، جاز کیش، بینک عملے یا یونیورسٹی افسر بن کر اکاؤنٹ کی تصدیق یا اسکالرشپ کے نام پر 4 یا 6 ہندسوں کا کوڈ مانگتے ہیں۔',
      sd: 'دوکيباز اڪثر ايزي پيسا، جاز ڪيش، بئنڪ عملي يا يونيورسٽي آفيسر بڻجي اڪائونٽ جي تصديق يا اسڪالرشپ جي نالي تي 4 يا 6 هندسن جو ڪوڊ گهرندا آهن.',
    },
    action: {
      en: 'Hang up immediately. No legitimate institution ever needs your OTP.',
      ur: 'فوری کال بند کریں۔ کوئی بھی اصل ادارہ آپ کا او ٹی پی نہیں مانگتا۔',
      sd: 'فوري ڪال بند ڪريو. ڪو به اصل ادارو توهان جو او ٽي پي نٿو گهري.',
    },
  },
  {
    id: 'tip-scholarships',
    category: 'portals',
    title: {
      en: 'Verify Scholarships Only on .gov.pk & .edu.pk',
      ur: 'اسکالرشپ کی تصدیق صرف .gov.pk اور .edu.pk پر کریں',
      sd: 'اسڪالرشپ جي تصديق رڳو .gov.pk ۽ .edu.pk تان ڪريو',
    },
    detail: {
      en: 'Official Sindh Endowment (SEEF), HEC, and public university portals always end in .gov.pk or .edu.pk. Fake sites use .xyz, .tk, .top, or lookalike spellings.',
      ur: 'سندھ انڈومنٹ (SEEF)، ایچ ای سی اور سرکاری یونیورسٹی پورٹلز ہمیشہ .gov.pk یا .edu.pk پر ختم ہوتے ہیں۔ جعلی سائٹس .xyz یا .tk استعمال کرتی ہیں۔',
      sd: 'سنڌ انڊومينٽ (SEEF)، ايڇ اي سي ۽ سرڪاري يونيورسٽي پورٽل هميشه .gov.pk يا .edu.pk تي ختم ٿيندا آهن. جعلي سائيٽون .xyz يا .tk استعمال ڪن ٿيون.',
    },
    action: {
      en: 'Check links with our Suspicious Link Checker before opening.',
      ur: 'کھولنے سے پہلے ہمارے لنک چیکر سے لنک کی جانچ کریں۔',
      sd: 'کولڻ کان اڳ اسان جي لنڪ چيڪر سان لنڪ جي جاچ ڪريو.',
    },
  },
  {
    id: 'tip-whatsapp',
    category: 'scam',
    title: {
      en: 'Protect Your WhatsApp with Two-Step PIN',
      ur: 'واٹس ایپ کو ٹو اسٹیپ پن سے محفوظ بنائیں',
      sd: 'واٽس ايپ کي ٽو اسٽيپ پن سان محفوظ بڻايو',
    },
    detail: {
      en: 'Hackers hijack student WhatsApp accounts by tricking them into forwarding a 6-digit SMS code, then use the account to ask classmates for urgent money.',
      ur: 'ہیکرز طلبہ کو دھوکہ دے کر 6 ہندسوں کا ایس ایم ایس کوڈ منگواتے ہیں اور پھر ان کے اکاؤنٹ سے دوستوں سے پیسے مانگتے ہیں۔',
      sd: 'هيڪرز شاگردن کي دوکو ڏئي 6 هندسن جو ايس ايم ايس ڪوڊ گهرائيندا آهن ۽ پوءِ دوستن کان پئسا گهرندا آهن.',
    },
    action: {
      en: 'Enable Two-Step Verification in WhatsApp Settings > Account.',
      ur: 'واٹس ایپ سیٹنگز > اکاؤنٹ میں جا کر ٹو اسٹیپ ویریفکیشن فعال کریں۔',
      sd: 'واٽس ايپ سيٽنگز > اڪائونٽ ۾ وڃي ٽو اسٽيپ ويريفيڪيشن آن ڪريو.',
    },
  },
  {
    id: 'tip-blackmail',
    category: 'bullying',
    title: {
      en: 'Save Evidence & Never Pay Blackmailers',
      ur: 'ثبوت محفوظ کریں اور بلیک میلرز کو پیسے نہ دیں',
      sd: 'ثبوت محفوظ ڪريو ۽ بليڪ ميلرن کي پئسا نه ڏيو',
    },
    detail: {
      en: 'Paying extortion money or replying in anger rarely stops cyberbullies — it often leads to repeated demands. Keeping calm and preserving evidence stops them.',
      ur: 'بلیک میلر کو پیسے دینے یا غصے میں جواب دینے سے ہراسانی رکتی نہیں بلکہ مزید مطالبات بڑھتے ہیں۔ ثبوت محفوظ رکھنا سب سے مؤثر ہے۔',
      sd: 'بليڪ ميلر کي پئسا ڏيڻ يا ڪاوڙ ۾ جواب ڏيڻ سان هراساني نٿي رڪجي، پر مطالبا وڌن ٿا. ثبوت محفوظ رکڻ سڀ کان بهتر طريقو آهي.',
    },
    action: {
      en: 'Screenshot chats, block the account, tell a parent/teacher, and call FIA 1991.',
      ur: 'اسکرین شاٹس لیں، اکاؤنٹ بلاک کریں، والدین/استاد کو بتائیں اور 1991 پر کال کریں۔',
      sd: 'اسڪرين شاٽ وٺو، اڪائونٽ بلاڪ ڪريو، والدين/استاد کي ٻڌايو ۽ 1991 تي ڪال ڪريو.',
    },
  },
  {
    id: 'tip-shortlinks',
    category: 'links',
    title: {
      en: 'Be Careful with Shortened URLs in Group Chats',
      ur: 'گروپ چیٹس میں مختصر لنکس سے ہوشیار رہیں',
      sd: 'گروپ چيٽس ۾ مختصر لنڪس کان هوشيار رهو',
    },
    detail: {
      en: 'Shortened links (like bit.ly or tinyurl) hide the real website address. Forwards claiming "Free GBs", "Exam Leak", or "Cash Reward" often install harmful APK files on Android.',
      ur: 'مختصر لنکس (bit.ly وغیرہ) اصل ویب سائٹ کو چھپاتے ہیں۔ "مفت انٹرنیٹ" یا "امتحانی پرچہ" کے جعلی لنکس اینڈرائیڈ فون میں خطرناک APK انسٹال کروا سکتے ہیں۔',
      sd: 'مختصر لنڪس (bit.ly وغيره) اصل ويب سائيٽ لڪائيندا آهن. "مفت انٽرنيٽ" يا "امتحاني پرچي" جا جعلي لنڪس اينڊرائيڊ فون ۾ خطرناڪ APK انسٽال ڪرائي سگهن ٿا.',
    },
    action: {
      en: 'Never install APK files sent via WhatsApp or Telegram.',
      ur: 'واٹس ایپ یا ٹیلی گرام پر بھیجی گئی کوئی APK فائل ہرگز انسٹال نہ کریں۔',
      sd: 'واٽس ايپ يا ٽيليگرام تي موڪليل ڪا به APK فائل هرگز انسٽال نه ڪريو.',
    },
  },
  {
    id: 'tip-privacy',
    category: 'bullying',
    title: {
      en: 'Lock Social Media Profiles & Restrict Unknown DMs',
      ur: 'سوشل میڈیا پروفائل لاک رکھیں اور نامعلوم پیغامات محدود کریں',
      sd: 'سوشل ميڊيا پروفائل لاڪ رکو ۽ اڻڄاتل پيغام محدود ڪريو',
    },
    detail: {
      en: 'Locking your Facebook profile and setting Instagram to Private prevents strangers from downloading your photos for fake accounts or harassment.',
      ur: 'فیس بک پروفائل لاک کرنے اور انسٹاگرام پرائیویٹ رکھنے سے اجنبی لوگ جعلی اکاؤنٹس بنانے کے لیے آپ کی تصاویر استعمال نہیں کر سکتے۔',
      sd: 'فيس بڪ پروفائل لاڪ ڪرڻ ۽ انسٽاگرام پرائيويٽ رکڻ سان اجنبي ماڻهو جعلي اڪائونٽ ٺاهڻ لاءِ توهان جون تصويرون استعمال نٿا ڪري سگهن.',
    },
    action: {
      en: 'Review your privacy settings once every semester.',
      ur: 'ہر سمسٹر میں کم از کم ایک بار اپنی پرائیویسی سیٹنگز کا جائزہ لیں۔',
      sd: 'هر سيميسٽر ۾ گهٽ ۾ گهٽ هڪ دفعو پنهنجي پرائيويسي سيٽنگز ضرور چيڪ ڪريو.',
    },
  },
];
