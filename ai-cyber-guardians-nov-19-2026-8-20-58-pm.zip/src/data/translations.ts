import type { ActiveView, Language, RiskLevel, ToolType } from '../types';

export interface TranslationBundle {
  brandName: string;
  brandSubtitle: string;
  nav: Record<ActiveView, string>;
  navShort: Record<ActiveView, string>;
  languageLabel: string;
  privacyBadge: string;
  privacyBanner: string;
  neverAskOtp: string;
  dashboard: {
    heroTitle: string;
    heroDesc: string;
    primaryCta: string;
    secondaryCta: string;
    sessionTitle: string;
    sessionSubtitle: string;
    clearSession: string;
    statTotal: string;
    statHigh: string;
    statMedium: string;
    statLow: string;
    toolsHeading: string;
    openTool: string;
    recentHeading: string;
    recentEmpty: string;
    recentEmptyAction: string;
    privacyCardTitle: string;
    privacyCardDesc: string;
  };
  tools: Record<
    ToolType,
    {
      title: string;
      subtitle: string;
      inputLabel: string;
      placeholder: string;
      analyzeBtn: string;
      analyzingBtn: string;
    }
  >;
  analyzer: {
    sampleTitle: string;
    clearBtn: string;
    pasteHint: string;
    riskLabel: string;
    riskLevels: Record<RiskLevel, string>;
    whySuspicious: string;
    recommendations: string;
    engineGemini: string;
    engineFallback: string;
    sensitiveWarningTitle: string;
    sensitiveWarningDesc: string;
    urlDetailsTitle: string;
    urlProtocol: string;
    urlHost: string;
    urlTld: string;
    urlOfficial: string;
    yes: string;
    no: string;
    copyAdvice: string;
    copied: string;
    errorEmpty: string;
  };
  tips: {
    title: string;
    subtitle: string;
    categories: {
      all: string;
      scam: string;
      links: string;
      bullying: string;
      portals: string;
    };
    checklistTitle: string;
    checklistSubtitle: string;
    checklistScore: string;
    checklistItems: string[];
  };
  about: {
    title: string;
    subtitle: string;
    missionTitle: string;
    missionBody: string;
    howItWorksTitle: string;
    howItWorksPoints: { title: string; desc: string }[];
    privacyTitle: string;
    privacyPoints: string[];
    helplinesTitle: string;
    helplinesSubtitle: string;
    helplines: { name: string; number: string; scope: string }[];
  };
}

export const TRANSLATIONS: Record<Language, TranslationBundle> = {
  en: {
    brandName: 'AI Cyber Guardian',
    brandSubtitle: 'Sindh Student Protection System',
    nav: {
      dashboard: 'Dashboard',
      scam: 'Scam Detector',
      link: 'Link Checker',
      cyberbullying: 'Cyberbullying',
      tips: 'Safety Tips',
      about: 'About Project',
    },
    navShort: {
      dashboard: 'Home',
      scam: 'Scam',
      link: 'Links',
      cyberbullying: 'Bullying',
      tips: 'Tips',
      about: 'About',
    },
    languageLabel: 'Language',
    privacyBadge: 'Zero Personal Data Stored',
    privacyBanner:
      'Privacy Guarantee: No personal data is stored. We never ask for passwords, PINs, or OTPs.',
    neverAskOtp: 'Never share your OTP, MPIN, or password with anyone.',
    dashboard: {
      heroTitle: 'Digital Safety Shield for Students Across Sindh',
      heroDesc:
        'Verify suspicious WhatsApp/SMS messages, inspect unknown website links, and detect online harassment instantly in English, Urdu, and Sindhi.',
      primaryCta: 'Scan a Message',
      secondaryCta: 'Check a Link',
      sessionTitle: 'Current Session Overview',
      sessionSubtitle: 'Held only in temporary memory and cleared when you close or reset.',
      clearSession: 'Clear Session',
      statTotal: 'Checks Run',
      statHigh: 'High Risk',
      statMedium: 'Medium Risk',
      statLow: 'Low Risk',
      toolsHeading: 'Protection Tools',
      openTool: 'Open Tool',
      recentHeading: 'Recent Session Checks',
      recentEmpty:
        'No checks run in this session yet. Test a sample scam message or paste a link to inspect.',
      recentEmptyAction: 'Try Scam Detector',
      privacyCardTitle: 'Zero Storage & No Passwords',
      privacyCardDesc:
        'Messages are analyzed statelessly and discarded. AI Cyber Guardian will never ask for your bank PIN, OTP code, CNIC photo, or account password.',
    },
    tools: {
      scam: {
        title: 'AI Scam Message Detector',
        subtitle:
          'Paste any SMS, WhatsApp forward, scholarship alert, or mobile wallet message to check for fraud.',
        inputLabel: 'Message to Analyze',
        placeholder:
          'Paste a suspicious SMS or WhatsApp message here (English, Urdu, or Sindhi)...',
        analyzeBtn: 'Analyze Message',
        analyzingBtn: 'Analyzing...',
      },
      link: {
        title: 'Suspicious Website Link Checker',
        subtitle:
          'Inspect scholarship, university, or banking URLs before opening them on your phone.',
        inputLabel: 'Website Link (URL)',
        placeholder: 'Paste a website link here (example: https://hec-scholarship-claim.xyz)...',
        analyzeBtn: 'Check Link',
        analyzingBtn: 'Inspecting Link...',
      },
      cyberbullying: {
        title: 'Cyberbullying Detector',
        subtitle:
          'Check abusive comments, threats, or blackmail messages and get safe, practical response steps.',
        inputLabel: 'Message or Comment',
        placeholder:
          'Paste a harassing comment, DM, or threatening message here...',
        analyzeBtn: 'Analyze Content',
        analyzingBtn: 'Analyzing...',
      },
    },
    analyzer: {
      sampleTitle: 'Sample Test Messages',
      clearBtn: 'Clear',
      pasteHint: 'Tip: Use a sample below to test how the detector works.',
      riskLabel: 'Risk Level',
      riskLevels: {
        Low: 'Low Risk',
        Medium: 'Medium Risk',
        High: 'High Risk',
      },
      whySuspicious: 'Why It Is Suspicious',
      recommendations: 'Safety Recommendations',
      engineGemini: 'Gemini AI Analysis',
      engineFallback: 'Rule-Based Protection Engine',
      sensitiveWarningTitle: 'Sensitive Code Detected in Input',
      sensitiveWarningDesc:
        'It looks like your text mentions an OTP, PIN, or password. Never share real codes or passwords with any person or website.',
      urlDetailsTitle: 'Link Structure Breakdown',
      urlProtocol: 'Protocol',
      urlHost: 'Domain Host',
      urlTld: 'Extension',
      urlOfficial: 'Official .edu.pk / .gov.pk',
      yes: 'Yes',
      no: 'No',
      copyAdvice: 'Copy Safety Advice',
      copied: 'Copied',
      errorEmpty: 'Please paste a message or link before running an analysis.',
    },
    tips: {
      title: 'Online Safety Tips for Students',
      subtitle:
        'Practical cyber hygiene tailored for school, college, and university students across Sindh.',
      categories: {
        all: 'All Tips',
        scam: 'Scams & OTPs',
        links: 'Links & Phishing',
        bullying: 'Cyberbullying',
        portals: 'Student Portals',
      },
      checklistTitle: 'Quick Student Safety Self-Check',
      checklistSubtitle: 'Tap each habit you actively follow on your Android phone.',
      checklistScore: 'habits active',
      checklistItems: [
        'I enabled Two-Step Verification (PIN) in WhatsApp Settings > Account.',
        'I never share Easypaisa, JazzCash, or bank OTP codes over phone calls or SMS.',
        'I verify scholarship and exam links end with .edu.pk or .gov.pk before entering details.',
        'I keep my Instagram and Facebook profiles private and review tagged posts.',
        'I take screenshots of threats before blocking bullies and inform a trusted elder or counselor.',
      ],
    },
    about: {
      title: 'About AI Cyber Guardian',
      subtitle: 'Sindh Student Protection System — Built for Everyday Digital Safety',
      missionTitle: 'Protecting Sindh’s Students Online',
      missionBody:
        'Students across Karachi, Hyderabad, Jamshoro, Sukkur, Larkana, Nawabshah, and Mirpurkhas rely on smartphones for scholarships, university admissions, and daily communication. Unfortunately, fake scholarship links, mobile wallet fraud, and online harassment increasingly target students. AI Cyber Guardian provides fast, free, multilingual protection right on your Android phone.',
      howItWorksTitle: 'Reliable Hybrid Architecture',
      howItWorksPoints: [
        {
          title: 'Gemini AI Analysis',
          desc: 'Uses Google Gemini AI to understand nuanced scam scripts, social engineering, and multilingual harassment in English, Urdu, and Sindhi.',
        },
        {
          title: 'Always-On Rule-Based Fallback',
          desc: 'If AI connectivity is unavailable or rate-limited, an instant deterministic rule engine checks URL anatomy, scam keywords, and threat patterns.',
        },
        {
          title: 'Sindh-Focused Context',
          desc: 'Recognizes official Pakistani educational and government domains (.edu.pk, .gov.pk) alongside common regional scam patterns.',
        },
      ],
      privacyTitle: 'Privacy & Safety Commitments',
      privacyPoints: [
        'Zero Personal Data Stored: No databases, no user accounts, and no permanent logs of your messages or links.',
        'Never Asks for Passwords or OTPs: This system only analyzes text you choose to inspect and never requests sensitive credentials.',
        'Session-Only Memory: Recent checks visible on your dashboard disappear as soon as you clear the session or close the tab.',
      ],
      helplinesTitle: 'Verified Helplines in Sindh & Pakistan',
      helplinesSubtitle: 'If you face financial fraud, blackmail, or severe cyberbullying, reach out to official support:',
      helplines: [
        {
          name: 'FIA Cyber Crime Wing (NR3C)',
          number: '1991',
          scope: 'National Cybercrime Reporting Helpline (24/7)',
        },
        {
          name: 'DRF Cyber Harassment Helpline',
          number: '0800-39393',
          scope: 'Free legal & digital safety support for students and women',
        },
        {
          name: 'Sindh Police Madadgar',
          number: '15',
          scope: 'Immediate emergency police assistance across Sindh',
        },
      ],
    },
  },
  ur: {
    brandName: 'اے آئی سائبر گارڈین',
    brandSubtitle: 'سندھ اسٹوڈنٹ پروٹیکشن سسٹم',
    nav: {
      dashboard: 'ڈیش بورڈ',
      scam: 'اسکیم ڈیٹیکٹر',
      link: 'لنک چیکر',
      cyberbullying: 'سائبر بلنگ',
      tips: 'حفاظتی نکات',
      about: 'پروجیکٹ کے بارے میں',
    },
    navShort: {
      dashboard: 'ہوم',
      scam: 'اسکیم',
      link: 'لنکس',
      cyberbullying: 'ہراسانی',
      tips: 'نکات',
      about: 'تعارف',
    },
    languageLabel: 'زبان',
    privacyBadge: 'کوئی ذاتی ڈیٹا محفوظ نہیں ہوتا',
    privacyBanner:
      'رازداری کی ضمانت: کوئی ذاتی معلومات محفوظ نہیں کی جاتیں۔ ہم کبھی پاس ورڈ، پن یا او ٹی پی نہیں مانگتے۔',
    neverAskOtp: 'کبھی بھی اپنا او ٹی پی، ایم پن یا پاس ورڈ کسی کو نہ بتائیں۔',
    dashboard: {
      heroTitle: 'سندھ بھر کے طلبہ کے لیے ڈیجیٹل حفاظتی ڈھال',
      heroDesc:
        'مشکوک واٹس ایپ اور ایس ایم ایس پیغامات، جعلی ویب سائٹ لنکس، اور آن لائن ہراسانی کی فوری جانچ اردو، سندھی اور انگریزی میں کریں۔',
      primaryCta: 'پیغام چیک کریں',
      secondaryCta: 'لنک چیک کریں',
      sessionTitle: 'موجودہ سیشن کا خلاصہ',
      sessionSubtitle: 'یہ تفصیل صرف عارضی میموری میں رہتی ہے اور ری سیٹ یا بند کرنے پر ختم ہو جاتی ہے۔',
      clearSession: 'سیشن صاف کریں',
      statTotal: 'کل جانچ',
      statHigh: 'زیادہ خطرہ',
      statMedium: 'درمیانہ خطرہ',
      statLow: 'کم خطرہ',
      toolsHeading: 'حفاظتی ٹولز',
      openTool: 'ٹول کھولیں',
      recentHeading: 'حالیہ سیشن کی جانچ',
      recentEmpty:
        'اس سیشن میں ابھی کوئی جانچ نہیں کی گئی۔ نیچے دیے گئے نمونے آزمائیں یا کوئی پیغام چسپاں کریں۔',
      recentEmptyAction: 'اسکیم ڈیٹیکٹر کھولیں',
      privacyCardTitle: 'زیرو اسٹوریج اور پاس ورڈ کی حفاظت',
      privacyCardDesc:
        'آپ کے پیغامات کہیں محفوظ نہیں کیے جاتے۔ اے آئی سائبر گارڈین کبھی بینک پن، او ٹی پی کوڈ، شناختی کارڈ یا پاس ورڈ نہیں مانگتا۔',
    },
    tools: {
      scam: {
        title: 'اے آئی اسکیم میسج ڈیٹیکٹر',
        subtitle:
          'فراڈ کی جانچ کے لیے کوئی بھی مشکوک ایس ایم ایس، واٹس ایپ پیغام یا اسکالرشپ الرٹ یہاں چسپاں کریں۔',
        inputLabel: 'جانچ کے لیے پیغام',
        placeholder: 'یہاں مشکوک ایس ایم ایس یا واٹس ایپ پیغام چسپاں کریں (اردو، سندھی یا انگریزی)...',
        analyzeBtn: 'پیغام کا تجزیہ کریں',
        analyzingBtn: 'تجزیہ جاری ہے...',
      },
      link: {
        title: 'مشکوک ویب سائٹ لنک چیکر',
        subtitle:
          'اپنے فون پر کھولنے سے پہلے اسکالرشپ، یونیورسٹی یا بینک کے لنک کی جانچ کریں۔',
        inputLabel: 'ویب سائٹ لنک (URL)',
        placeholder: 'یہاں ویب سائٹ کا لنک چسپاں کریں (مثال: https://hec-scholarship-claim.xyz)...',
        analyzeBtn: 'لنک چیک کریں',
        analyzingBtn: 'لنک کی جانچ جاری ہے...',
      },
      cyberbullying: {
        title: 'سائبر بلنگ ڈیٹیکٹر',
        subtitle:
          'دھمکی آمیز، توہین آمیز یا بلیک میلنگ والے پیغامات کی جانچ کریں اور محفوظ حفاظتی رہنمائی حاصل کریں۔',
        inputLabel: 'پیغام یا تبصرہ',
        placeholder: 'یہاں ہراسانی، دھمکی یا بلیک میلنگ والا پیغام چسپاں کریں...',
        analyzeBtn: 'مواد چیک کریں',
        analyzingBtn: 'تجزیہ جاری ہے...',
      },
    },
    analyzer: {
      sampleTitle: 'آزمائشی نمونہ پیغامات',
      clearBtn: 'صاف کریں',
      pasteHint: 'مشورہ: ٹیسٹ کرنے کے لیے نیچے دیے گئے کسی بھی نمونے پر ٹیپ کریں۔',
      riskLabel: 'خطرے کی سطح',
      riskLevels: {
        Low: 'کم خطرہ',
        Medium: 'درمیانہ خطرہ',
        High: 'زیادہ خطرہ',
      },
      whySuspicious: 'یہ کیوں مشکوک ہے',
      recommendations: 'حفاظتی سفارشات',
      engineGemini: 'جیمنی اے آئی تجزیہ',
      engineFallback: 'اصول پر مبنی حفاظتی انجن',
      sensitiveWarningTitle: 'حساس کوڈ کی نشاندہی ہوئی',
      sensitiveWarningDesc:
        'آپ کے متن میں او ٹی پی، پن یا پاس ورڈ کا ذکر ہے۔ کبھی بھی اصلی کوڈ یا پاس ورڈ کسی شخص یا ویب سائٹ کو نہ دیں۔',
      urlDetailsTitle: 'لنک کی ساخت کا تفصیلی جائزہ',
      urlProtocol: 'پروٹوکول',
      urlHost: 'ڈومین ہوسٹ',
      urlTld: 'ایکسٹینشن',
      urlOfficial: 'سرکاری .edu.pk / .gov.pk',
      yes: 'جی ہاں',
      no: 'نہیں',
      copyAdvice: 'حفاظتی مشورہ کاپی کریں',
      copied: 'کاپی ہو گیا',
      errorEmpty: 'تجزیہ شروع کرنے سے پہلے براہ کرم کوئی پیغام یا لنک درج کریں۔',
    },
    tips: {
      title: 'طلبہ کے لیے آن لائن حفاظتی نکات',
      subtitle:
        'سندھ کے اسکول، کالج اور یونیورسٹی طلبہ کے لیے عملی ڈیجیٹل حفاظتی رہنمائی۔',
      categories: {
        all: 'تمام نکات',
        scam: 'فراڈ اور او ٹی پی',
        links: 'مشکوک لنکس',
        bullying: 'سائبر بلنگ',
        portals: 'تعلیمی پورٹلز',
      },
      checklistTitle: 'طلبہ کی فوری حفاظتی جانچ',
      checklistSubtitle: 'ہر اس عادت پر کلک کریں جو آپ اپنے فون پر اپناتے ہیں۔',
      checklistScore: 'عادات فعال',
      checklistItems: [
        'میں نے واٹس ایپ سیٹنگز > اکاؤنٹ میں ٹو اسٹیپ ویریفکیشن (PIN) آن کر رکھی ہے۔',
        'میں کبھی ایزی پیسہ، جاز کیش یا بینک کا او ٹی پی کوڈ کال یا ایس ایم ایس پر نہیں بتاتا۔',
        'تفصیلات درج کرنے سے پہلے چیک کرتا ہوں کہ اسکالرشپ یا امتحانی لنک .edu.pk یا .gov.pk پر ختم ہوتا ہے۔',
        'میں نے اپنے انسٹاگرام اور فیس بک اکاؤنٹس پرائیویٹ رکھے ہوئے ہیں۔',
        'ہراساں کرنے والے کو بلاک کرنے سے پہلے اسکرین شاٹس محفوظ کر کے والدین یا استاد کو بتاتا ہوں۔',
      ],
    },
    about: {
      title: 'اے آئی سائبر گارڈین کے بارے میں',
      subtitle: 'سندھ اسٹوڈنٹ پروٹیکشن سسٹم — روزمرہ ڈیجیٹل تحفظ کے لیے',
      missionTitle: 'سندھ کے طلبہ کا آن لائن تحفظ',
      missionBody:
        'کراچی، حیدرآباد، جامشورو، سکھر، لاڑکانہ، نوابشاہ اور میرپورخاص کے طلبہ اسکالرشپ، یونیورسٹی داخلوں اور رابطوں کے لیے اسمارٹ فون استعمال کرتے ہیں۔ جعلی اسکالرشپ لنکس، موبائل والٹ فراڈ اور آن لائن ہراسانی سے بچاؤ کے لیے یہ سسٹم اردو، سندھی اور انگریزی میں مفت تحفظ فراہم کرتا ہے۔',
      howItWorksTitle: 'مضبوط اور قابلِ اعتماد نظام',
      howItWorksPoints: [
        {
          title: 'جیمنی اے آئی تجزیہ',
          desc: 'اردو، سندھی اور انگریزی میں پیچیدہ فراڈ پیغامات، جعلی لالچ اور ہراسانی کو سمجھنے کے لیے گوگل جیمنی اے آئی کا استعمال۔',
        },
        {
          title: 'خودکار رول بیسڈ بیک اپ',
          desc: 'اگر اے آئی سروس دستیاب نہ ہو تو فوری اصول پر مبنی انجن لنکس، فراڈ الفاظ اور دھمکیوں کی جانچ کرتا ہے۔',
        },
        {
          title: 'مقامی تعلیمی آگاہی',
          desc: 'پاکستان کے سرکاری اور تعلیمی ڈومینز (.edu.pk اور .gov.pk) کی پہچان اور مقامی فراڈ طریقوں کی شناخت۔',
        },
      ],
      privacyTitle: 'رازداری اور تحفظ کے اصول',
      privacyPoints: [
        'ذاتی ڈیٹا محفوظ نہیں ہوتا: کوئی ڈیٹابیس، لاگ ان یا پیغامات کا مستقل ریکارڈ نہیں رکھا جاتا۔',
        'پاس ورڈ یا او ٹی پی کبھی نہیں مانگا جاتا: یہ سسٹم صرف آپ کے درج کردہ متن کا تجزیہ کرتا ہے۔',
        'عارضی سیشن میموری: ڈیش بورڈ پر نظر آنے والی حالیہ جانچ ٹیب بند کرنے یا صاف کرنے پر فوراً مٹ جاتی ہے۔',
      ],
      helplinesTitle: 'سندھ اور پاکستان کی سرکاری ہیلپ لائنز',
      helplinesSubtitle: 'مالی فراڈ، بلیک میلنگ یا شدید سائبر ہراسانی کی صورت میں فوری رابطہ کریں:',
      helplines: [
        {
          name: 'ایف آئی اے سائبر کرائم ونگ',
          number: '1991',
          scope: 'قومی سائبر کرائم ہیلپ لائن (24 گھنٹے)',
        },
        {
          name: 'ڈی آر ایف سائبر ہراسانی ہیلپ لائن',
          number: '0800-39393',
          scope: 'طلبہ اور خواتین کے لیے مفت قانونی و ڈیجیٹل مدد',
        },
        {
          name: 'سندھ پولیس مددگار',
          number: '15',
          scope: 'سندھ بھر میں فوری ہنگامی پولیس مدد',
        },
      ],
    },
  },
  sd: {
    brandName: 'اي آءِ سائبر گارڊين',
    brandSubtitle: 'سنڌ اسٽوڊنٽ پروٽيڪشن سسٽم',
    nav: {
      dashboard: 'ڊيش بورڊ',
      scam: 'اسڪيم ڊيٽيڪٽر',
      link: 'لنڪ چيڪر',
      cyberbullying: 'سائبر بلنگ',
      tips: 'حفاظتي ٽوٽڪا',
      about: 'پروجيڪٽ بابت',
    },
    navShort: {
      dashboard: 'گهر',
      scam: 'اسڪيم',
      link: 'لنڪس',
      cyberbullying: 'هراساني',
      tips: 'نڪتا',
      about: 'تعارف',
    },
    languageLabel: 'ٻولي',
    privacyBadge: 'ذاتي ڊيٽا محفوظ نٿي ٿئي',
    privacyBanner:
      'رازداري جي ضمانت: ڪا به ذاتي معلومات محفوظ نٿي ڪئي وڃي. اسان ڪڏهن به پاسورڊ، پن يا او ٽي پي نٿا گهرون.',
    neverAskOtp: 'ڪڏهن به پنهنجو او ٽي پي، ايم پن يا پاسورڊ ڪنهن سان شيئر نه ڪريو.',
    dashboard: {
      heroTitle: 'سنڌ جي شاگردن لاءِ ڊجيٽل حفاظتي ڍال',
      heroDesc:
        'مشڪوڪ واٽس ايپ ۽ ايس ايم ايس پيغامن، جعلي ويب سائيٽ لنڪس، ۽ آن لائين هراساني جي فوري جاچ سنڌي، اردو ۽ انگريزي ۾ ڪريو.',
      primaryCta: 'پيغام چيڪ ڪريو',
      secondaryCta: 'لنڪ چيڪ ڪريو',
      sessionTitle: 'موجوده سيشن جو خلاصو',
      sessionSubtitle: 'هي معلومات رڳو عارضي ميموري ۾ رهي ٿي ۽ بند ڪرڻ يا صاف ڪرڻ تي ختم ٿي وڃي ٿي.',
      clearSession: 'سيشن صاف ڪريو',
      statTotal: 'ڪل جاچ',
      statHigh: 'وڌيڪ خطرو',
      statMedium: 'وچولو خطرو',
      statLow: 'گهٽ خطرو',
      toolsHeading: 'حفاظتي اوزار',
      openTool: 'اوزار کوليو',
      recentHeading: 'تازيون سيشن جاچون',
      recentEmpty:
        'هن سيشن ۾ اڃا تائين ڪا جاچ ناهي ٿي. هيٺ ڏنل نمونا آزمايو يا ڪو پيغام پيسٽ ڪريو.',
      recentEmptyAction: 'اسڪيم ڊيٽيڪٽر کوليو',
      privacyCardTitle: 'زيرو اسٽوريج ۽ پاسورڊ حفاظت',
      privacyCardDesc:
        'توهان جا پيغام ڪٿي به محفوظ نٿا ڪيا وڃن. اي آءِ سائبر گارڊين ڪڏهن به بئنڪ پن، او ٽي پي ڪوڊ، يا پاسورڊ نٿو گهري.',
    },
    tools: {
      scam: {
        title: 'اي آءِ اسڪيم ميسيج ڊيٽيڪٽر',
        subtitle:
          'دوکي جي سڃاڻپ لاءِ ڪو به مشڪوڪ ايس ايم ايس، واٽس ايپ پيغام يا اسڪالرشپ الرٽ هتي پيسٽ ڪريو.',
        inputLabel: 'جاچ لاءِ پيغام',
        placeholder: 'هتي مشڪوڪ ايس ايم ايس يا واٽس ايپ پيغام پيسٽ ڪريو (سنڌي، اردو يا انگريزي)...',
        analyzeBtn: 'پيغام جو تجزيو ڪريو',
        analyzingBtn: 'تجزيو جاري آهي...',
      },
      link: {
        title: 'مشڪوڪ ويب سائيٽ لنڪ چيڪر',
        subtitle:
          'فون تي کولڻ کان اڳ اسڪالرشپ، يونيورسٽي يا بئنڪ جي لنڪ جي جاچ ڪريو.',
        inputLabel: 'ويب سائيٽ لنڪ (URL)',
        placeholder: 'هتي ويب سائيٽ لنڪ پيسٽ ڪريو (مثال: https://hec-scholarship-claim.xyz)...',
        analyzeBtn: 'لنڪ چيڪ ڪريو',
        analyzingBtn: 'لنڪ جي جاچ جاري آهي...',
      },
      cyberbullying: {
        title: 'سائبر بلنگ ڊيٽيڪٽر',
        subtitle:
          'ڌمڪين، توهين يا بليڪ ميلنگ وارن پيغامن جي جاچ ڪريو ۽ محفوظ حفاظتي رهنمائي حاصل ڪريو.',
        inputLabel: 'پيغام يا تبصرو',
        placeholder: 'هتي هراساني، ڌمڪي يا بليڪ ميلنگ وارو پيغام پيسٽ ڪريو...',
        analyzeBtn: 'مواد چيڪ ڪريو',
        analyzingBtn: 'تجزيو جاري آهي...',
      },
    },
    analyzer: {
      sampleTitle: 'آزمائشي نموني جا پيغام',
      clearBtn: 'صاف ڪريو',
      pasteHint: 'صلاح: ٽيسٽ ڪرڻ لاءِ هيٺ ڏنل ڪنهن به نموني تي ٽيپ ڪريو.',
      riskLabel: 'خطري جي سطح',
      riskLevels: {
        Low: 'گهٽ خطرو',
        Medium: 'وچولو خطرو',
        High: 'وڌيڪ خطرو',
      },
      whySuspicious: 'هي ڇو مشڪوڪ آهي',
      recommendations: 'حفاظتي سفارشون',
      engineGemini: 'جيميني اي آءِ تجزيو',
      engineFallback: 'رول بيسڊ حفاظتي انجڻ',
      sensitiveWarningTitle: 'حساس ڪوڊ جي نشاندهي ٿي',
      sensitiveWarningDesc:
        'توهان جي متن ۾ او ٽي پي، پن يا پاسورڊ جو ذڪر آهي. ڪڏهن به اصل ڪوڊ يا پاسورڊ ڪنهن شخص يا ويب سائيٽ کي نه ڏيو.',
      urlDetailsTitle: 'لنڪ جي بناوٽ جو تفصيل',
      urlProtocol: 'پروٽوڪول',
      urlHost: 'ڊومين هوسٽ',
      urlTld: 'ايڪسٽينشن',
      urlOfficial: 'سرڪاري .edu.pk / .gov.pk',
      yes: 'ها',
      no: 'نه',
      copyAdvice: 'حفاظتي صلاح ڪاپي ڪريو',
      copied: 'ڪاپي ٿي ويو',
      errorEmpty: 'تجزيو شروع ڪرڻ کان اڳ مهرباني ڪري ڪو پيغام يا لنڪ داخل ڪريو.',
    },
    tips: {
      title: 'شاگردن لاءِ آن لائين حفاظتي ٽوٽڪا',
      subtitle:
        'سنڌ جي اسڪولن، ڪاليجن ۽ يونيورسٽين جي شاگردن لاءِ عملي ڊجيٽل حفاظتي رهنمائي.',
      categories: {
        all: 'سڀ نڪتا',
        scam: 'دوکو ۽ او ٽي پي',
        links: 'مشڪوڪ لنڪس',
        bullying: 'سائبر بلنگ',
        portals: 'تعليمي پورٽلز',
      },
      checklistTitle: 'شاگردن جي فوري حفاظتي جاچ',
      checklistSubtitle: 'هر ان عادت تي ڪلڪ ڪريو جيڪا توهان پنهنجي فون تي اپنايو ٿا.',
      checklistScore: 'عادتون فعال',
      checklistItems: [
        'مون واٽس ايپ سيٽنگز > اڪائونٽ ۾ ٽو اسٽيپ ويريفيڪيشن (PIN) آن ڪري رکي آهي.',
        'مان ڪڏهن به ايزي پيسا، جاز ڪيش يا بئنڪ جو او ٽي پي ڪوڊ فون يا ايس ايم ايس تي نٿو ٻڌايان.',
        'معلومات داخل ڪرڻ کان اڳ پڪ ڪريان ٿو ته اسڪالرشپ يا امتحاني لنڪ .edu.pk يا .gov.pk تي ختم ٿئي.',
        'مون پنهنجا انسٽاگرام ۽ فيس بڪ اڪائونٽ پرائيويٽ رکيا آهن.',
        'هراسان ڪندڙ کي بلاڪ ڪرڻ کان اڳ اسڪرين شاٽ محفوظ ڪري والدين يا استاد کي ٻڌايان ٿو.',
      ],
    },
    about: {
      title: 'اي آءِ سائبر گارڊين بابت',
      subtitle: 'سنڌ اسٽوڊنٽ پروٽيڪشن سسٽم — روزاني ڊجيٽل تحفظ لاءِ',
      missionTitle: 'سنڌ جي شاگردن جو آن لائين تحفظ',
      missionBody:
        'ڪراچي، حيدرآباد، ڄامشورو، سکر، لاڙڪاڻو، نوابشاهه ۽ ميرپورخاص جا شاگرد اسڪالرشپس، يونيورسٽي داخلا ۽ رابطي لاءِ اسمارٽ فون استعمال ڪن ٿا. جعلي اسڪالرشپ لنڪس، موبائل والٽ فراڊ ۽ آن لائين هراساني کان بچاءَ لاءِ هي سسٽم سنڌي، اردو ۽ انگريزي ۾ مفت تحفظ فراهم ڪري ٿو.',
      howItWorksTitle: 'مضبوط هائبرڊ نظام',
      howItWorksPoints: [
        {
          title: 'جيميني اي آءِ تجزيو',
          desc: 'سنڌي، اردو ۽ انگريزي ۾ ڏکين دوکي وارن پيغامن ۽ هراساني کي سمجهڻ لاءِ گوگل جيميني اي آءِ جو استعمال.',
        },
        {
          title: 'هميشه تيار رول بيسڊ بئڪ اپ',
          desc: 'جيڪڏهن اي آءِ سروس دستياب نه هجي ته فوري رول بيسڊ انجڻ لنڪس، دوکي وارن لفظن ۽ ڌمڪين جي جاچ ڪري ٿي.',
        },
        {
          title: 'سنڌ جو مقامي تناظر',
          desc: 'پاڪستان جي سرڪاري ۽ تعليمي ڊومينز (.edu.pk ۽ .gov.pk) جي سڃاڻپ ۽ مقامي اسڪيمن جي نشاندهي.',
        },
      ],
      privacyTitle: 'رازداري ۽ تحفظ جا اصول',
      privacyPoints: [
        'ذاتي ڊيٽا محفوظ نٿي ٿئي: ڪو به ڊيٽابيس، لاگ ان يا پيغامن جو مستقل رڪارڊ نٿو رکيو وڃي.',
        'پاسورڊ يا او ٽي پي ڪڏهن نٿو گهريو وڃي: هي سسٽم رڳو توهان جي ڏنل متن جو تجزيو ڪري ٿو.',
        'عارضي سيشن ميموري: ڊيش بورڊ تي نظر ايندڙ تازيون جاچون ٽيب بند ڪرڻ يا صاف ڪرڻ سان فوري مٽجي وڃن ٿيون.',
      ],
      helplinesTitle: 'سنڌ ۽ پاڪستان جون سرڪاري هيلپ لائينز',
      helplinesSubtitle: 'مالي دوکي، بليڪ ميلنگ يا سخت سائبر هراساني جي صورت ۾ فوري رابطو ڪريو:',
      helplines: [
        {
          name: 'ايف آءِ اي سائبر ڪرائم ونگ',
          number: '1991',
          scope: 'قومي سائبر ڪرائم هيلپ لائين (24 ڪلاڪ)',
        },
        {
          name: 'ڊي آر ايف سائبر هراساني هيلپ لائين',
          number: '0800-39393',
          scope: 'شاگردن ۽ عورتن لاءِ مفت قانوني ۽ ڊجيٽل مدد',
        },
        {
          name: 'سنڌ پوليس مددگار',
          number: '15',
          scope: 'سنڌ ڀر ۾ فوري هنگامي پوليس مدد',
        },
      ],
    },
  },
};
