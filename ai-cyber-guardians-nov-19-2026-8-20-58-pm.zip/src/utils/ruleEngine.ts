import type {
  AnalysisResult,
  Language,
  RiskLevel,
  ToolType,
  UrlInspectionDetails,
} from '../types.ts';

const SUSPICIOUS_TLDS = new Set([
  'xyz',
  'tk',
  'ml',
  'ga',
  'cf',
  'gq',
  'top',
  'click',
  'loan',
  'work',
  'buzz',
  'club',
  'icu',
  'cam',
  'cfd',
  'rest',
  'monster',
  'zip',
]);

const URL_SHORTENERS = new Set([
  'bit.ly',
  'tinyurl.com',
  't.co',
  'goo.gl',
  'ow.ly',
  'is.gd',
  'buff.ly',
  'rb.gy',
  'cutt.ly',
  'shorturl.at',
  'tiny.cc',
  'rebrand.ly',
]);

const OFFICIAL_SAFE_DOMAINS = [
  'hec.gov.pk',
  'sindh.gov.pk',
  'seef.sindh.gov.pk',
  'muet.edu.pk',
  'uok.edu.pk',
  'usindh.edu.pk',
  'iba-suk.edu.pk',
  'quest.edu.pk',
  'lumhs.edu.pk',
  'smbbmu.edu.pk',
  'salu.edu.pk',
  'duhs.edu.pk',
  'neduet.edu.pk',
  'iba.edu.pk',
  'biseh.edu.pk',
  'bisek.edu.pk',
  'bisesukkur.edu.pk',
  'biselrk.edu.pk',
  'nadra.gov.pk',
  'pta.gov.pk',
  'fia.gov.pk',
  'bisp.gov.pk',
];

const BRAND_IMPERSONATION_WORDS = [
  'easypaisa',
  'jazzcash',
  'sadapay',
  'nayapay',
  'bisp',
  'ehsaas',
  'hec',
  'sindh',
  'scholarship',
  'nadra',
  'pta',
  'whatsapp',
  'facebook',
  'instagram',
  'paypal',
  'bank',
  'hbl',
  'meezan',
  'ubl',
  'mcb',
];

const CREDENTIAL_KEYWORDS = [
  'login',
  'verify',
  'otp',
  'pin',
  'mpin',
  'password',
  'claim',
  'reward',
  'prize',
  'winner',
  'bonus',
  'free',
  'urgent',
  'update-account',
  'suspended',
  'confirm',
];

export function inspectUrlStructure(rawInput: string): {
  valid: boolean;
  details?: UrlInspectionDetails;
  hasAtTrick: boolean;
  hasPunycode: boolean;
} {
  let candidate = rawInput.trim();
  const urlMatch = candidate.match(/https?:\/\/[^\s]+/i);
  if (urlMatch) {
    candidate = urlMatch[0];
  } else if (!/^https?:\/\//i.test(candidate) && /^[^\s]+\.[^\s]+/.test(candidate)) {
    candidate = `http://${candidate}`;
  }

  try {
    const parsed = new URL(candidate);
    const hostname = parsed.hostname.toLowerCase();
    const parts = hostname.split('.').filter(Boolean);
    const tld = parts.length > 0 ? parts[parts.length - 1] : '';
    const isHttps = parsed.protocol === 'https:';
    const hasIpHost =
      /^\d{1,3}(\.\d{1,3}){3}$/.test(hostname) || hostname.startsWith('[');
    const isOfficialPkDomain =
      hostname.endsWith('.edu.pk') ||
      hostname.endsWith('.gov.pk') ||
      OFFICIAL_SAFE_DOMAINS.some(
        (d) => hostname === d || hostname.endsWith(`.${d}`),
      );
    const isShortener = URL_SHORTENERS.has(hostname);
    const hasSuspiciousTld = SUSPICIOUS_TLDS.has(tld);
    const subdomainCount = Math.max(0, parts.length - 2);
    const hasAtTrick = rawInput.includes('@') && parsed.username !== '';
    const hasPunycode = hostname.includes('xn--');

    const fullLower = `${hostname}${parsed.pathname}${parsed.search}`.toLowerCase();
    const flaggedKeywords = [
      ...BRAND_IMPERSONATION_WORDS.filter(
        (w) => fullLower.includes(w) && !isOfficialPkDomain,
      ),
      ...CREDENTIAL_KEYWORDS.filter((w) => fullLower.includes(w)),
    ];

    return {
      valid: true,
      hasAtTrick,
      hasPunycode,
      details: {
        normalizedUrl: parsed.toString(),
        protocol: parsed.protocol.replace(':', '').toUpperCase(),
        hostname,
        tld: tld ? `.${tld}` : 'none',
        isHttps,
        isOfficialPkDomain,
        isShortener,
        hasIpHost,
        hasSuspiciousTld,
        subdomainCount,
        flaggedKeywords: Array.from(new Set(flaggedKeywords)),
      },
    };
  } catch {
    return { valid: false, hasAtTrick: false, hasPunycode: false };
  }
}

export function detectSensitiveDataPattern(text: string): boolean {
  const hasOtpLike =
    /\b(otp|pin|mpin|code|passcode|password)\b[\s:=-]*\d{4,8}\b/i.test(text);
  const hasPasswordPair = /\b(password|pass|pin)\s*[:=]\s*\S{4,}/i.test(text);
  return hasOtpLike || hasPasswordPair;
}

type LocalizedText = Record<Language, string>;

const L = (en: string, ur: string, sd: string): LocalizedText => ({ en, ur, sd });

export function runRuleBasedAnalysis(
  tool: ToolType,
  input: string,
  language: Language,
  fallbackNotice?: string,
): AnalysisResult {
  const text = input.trim();
  const containsSensitivePattern = detectSensitiveDataPattern(text);
  const analyzedAt = new Date().toISOString();

  if (tool === 'link') {
    const inspected = inspectUrlStructure(text);
    if (!inspected.valid || !inspected.details) {
      return {
        tool,
        language,
        riskLevel: 'Medium',
        summary: L(
          'Could not parse a standard web link; treat unverified text links with caution.',
          'معیاری ویب لنک کی شناخت نہیں ہو سکی؛ غیر تصدیق شدہ لنکس پر احتیاط برتیں۔',
          'معياري ويب لنڪ جي سڃاڻپ نه ٿي سگهي؛ غير تصديق ٿيل لنڪس تي احتياط ڪريو.',
        )[language],
        reasons: [
          L(
            'The entered text does not match a valid website address format (example: https://hec.gov.pk).',
            'درج کردہ متن درست ویب سائٹ ایڈریس کی شکل میں نہیں ہے (مثال: https://hec.gov.pk)۔',
            'داخل ڪيل متن صحيح ويب سائيٽ ايڊريس جي شڪل ۾ ناهي (مثال: https://hec.gov.pk).',
          )[language],
        ],
        recommendations: [
          L(
            'Copy the complete link starting with https:// before checking it.',
            'چیک کرنے سے پہلے https:// سے شروع ہونے والا مکمل لنک کاپی کریں۔',
            'چيڪ ڪرڻ کان اڳ https:// سان شروع ٿيندڙ مڪمل لنڪ ڪاپي ڪريو.',
          )[language],
          L(
            'Never tap shortened or misspelled links sent by unknown numbers.',
            'نامعلوم نمبروں سے بھیجے گئے مختصر یا غلط ہجے والے لنکس پر ہرگز کلک نہ کریں۔',
            'اڻڄاتل نمبرن مان موڪليل مختصر يا غلط هجي وارن لنڪس تي هرگز ڪلڪ نه ڪريو.',
          )[language],
        ],
        engine: 'rule-based',
        fallbackNotice,
        containsSensitivePattern,
        analyzedAt,
      };
    }

    const d = inspected.details;
    let score = 0;
    const reasons: string[] = [];

    if (!d.isHttps) {
      score += 2;
      reasons.push(
        L(
          'Uses unencrypted HTTP instead of HTTPS — data sent on this site is not encrypted.',
          'یہ لنک HTTPS کے بجائے غیر محفوظ HTTP استعمال کرتا ہے — اس ویب سائٹ پر بھیجا گیا ڈیٹا محفوظ نہیں ہوتا۔',
          'هي لنڪ HTTPS بدران غير محفوظ HTTP استعمال ڪري ٿو — هن سائيٽ تي موڪليل ڊيٽا محفوظ ناهي.',
        )[language],
      );
    }
    if (d.hasIpHost) {
      score += 4;
      reasons.push(
        L(
          'Uses a raw IP address instead of a legitimate domain name, a common phishing indicator.',
          'اصل ڈومین نام کے بجائے براہِ راست IP ایڈریس استعمال کیا گیا ہے جو فشنگ کی عام علامت ہے۔',
          'اصلي ڊومين نالي بدران سڌو IP ايڊريس استعمال ٿيل آهي، جيڪو فشنگ جي عام نشاني آهي.',
        )[language],
      );
    }
    if (inspected.hasAtTrick) {
      score += 4;
      reasons.push(
        L(
          'Contains an "@" symbol in the URL authority, which can trick browsers into visiting a different host.',
          'لنک میں "@" کی علامت موجود ہے جو صارف کو دھوکہ دے کر کسی دوسری ویب سائٹ پر لے جا سکتی ہے۔',
          'لنڪ ۾ "@" جي نشاني موجود آهي جيڪا صارف کي دوکو ڏئي ٻئي ويب سائيٽ تي وٺي وڃي سگهي ٿي.',
        )[language],
      );
    }
    if (inspected.hasPunycode) {
      score += 3;
      reasons.push(
        L(
          'Uses Punycode (xn--) characters that can impersonate trusted domain spellings.',
          'اس لنک میں Punycode (xn--) حروف ہیں جو قابلِ اعتماد ویب سائٹس کی نقل کرنے کے لیے استعمال ہوتے ہیں۔',
          'هن لنڪ ۾ Punycode (xn--) اکر آهن جيڪي معتبر ويب سائيٽن جي نقل لاءِ استعمال ٿي سگهن ٿا.',
        )[language],
      );
    }
    if (d.hasSuspiciousTld) {
      score += 3;
      reasons.push(
        L(
          `Uses a high-risk top-level domain (${d.tld}) frequently abused for temporary scam sites.`,
          `یہ لنک مشکوک ڈومین ایکسٹینشن (${d.tld}) استعمال کرتا ہے جو اکثر جعلی ویب سائٹس میں دیکھی جاتی ہے۔`,
          `هي لنڪ مشڪوڪ ڊومين ايڪسٽينشن (${d.tld}) استعمال ڪري ٿو جيڪا اڪثر جعلي سائيٽن لاءِ استعمال ٿيندي آهي.`,
        )[language],
      );
    }
    if (d.isShortener) {
      score += 2;
      reasons.push(
        L(
          'Uses a URL shortener that hides the true destination website.',
          'یہ ایک مختصر لنک (URL Shortener) ہے جو اصل ویب سائٹ کا پتہ چھپاتا ہے۔',
          'هي هڪ مختصر لنڪ (URL Shortener) آهي جيڪو اصل ويب سائيٽ جو پتو لڪائي ٿو.',
        )[language],
      );
    }
    if (d.subdomainCount >= 3) {
      score += 2;
      reasons.push(
        L(
          'Has an unusually deep subdomain chain designed to look like an official portal.',
          'اس میں غیر معمولی طور پر کئی سب ڈومینز شامل ہیں جو سرکاری پورٹل کا دھوکہ دینے کے لیے بنائے جاتے ہیں۔',
          'هن ۾ غير معمولي طور تي گھڻا سب ڊومينز شامل آهن جيڪي سرڪاري پورٽل جو دوکو ڏيڻ لاءِ ٺاهيا ويندا آهن.',
        )[language],
      );
    }
    if (d.flaggedKeywords.length > 0) {
      score += d.flaggedKeywords.length >= 2 ? 4 : 2;
      reasons.push(
        L(
          `Contains sensitive or impersonated terms (${d.flaggedKeywords.slice(0, 4).join(', ')}) on an unverified domain.`,
          `غیر تصدیق شدہ ڈومین میں حساس یا نقل شدہ الفاظ (${d.flaggedKeywords.slice(0, 4).join('، ')}) شامل ہیں۔`,
          `غير تصديق ٿيل ڊومين ۾ حساس يا نقل ٿيل لفظ (${d.flaggedKeywords.slice(0, 4).join('، ')}) شامل آهن.`,
        )[language],
      );
    }

    let riskLevel: RiskLevel = 'Low';
    if (d.isOfficialPkDomain && score <= 1) {
      riskLevel = 'Low';
    } else if (score >= 5) {
      riskLevel = 'High';
    } else if (score >= 2) {
      riskLevel = 'Medium';
    }

    if (reasons.length === 0) {
      reasons.push(
        d.isOfficialPkDomain
          ? L(
              `Uses HTTPS and belongs to an official Pakistani educational or government domain (${d.hostname}).`,
              `یہ لنک محفوظ HTTPS استعمال کرتا ہے اور پاکستان کے سرکاری یا تعلیمی ڈومین (${d.hostname}) سے تعلق رکھتا ہے۔`,
              `هي لنڪ محفوظ HTTPS استعمال ڪري ٿو ۽ پاڪستان جي سرڪاري يا تعليمي ڊومين (${d.hostname}) سان لاڳاپيل آهي.`,
            )[language]
          : L(
              'No obvious structural phishing markers were found, though unknown third-party sites still require verification.',
              'ظاہری طور پر فشنگ کی بڑی علامت نہیں ملی، لیکن نامعلوم ویب سائٹس کی تصدیق ضروری ہے۔',
              'ظاهري طور تي فشنگ جي وڏي نشاني نه ملي آهي، پر اڻڄاتل ويب سائيٽن جي تصديق ضروري آهي.',
            )[language],
      );
    }

    const summary =
      riskLevel === 'High'
        ? L(
            'High-risk link detected: multiple phishing or impersonation indicators found.',
            'خطرناک لنک کی نشاندہی: فشنگ یا جعلی ویب سائٹ کے متعدد شواہد موجود ہیں۔',
            'خطرناڪ لنڪ جي نشاندهي: فشنگ يا جعلي ويب سائيٽ جا ڪيترائي ثبوت موجود آهن.',
          )[language]
        : riskLevel === 'Medium'
          ? L(
              'Suspicious link characteristics found — verify the domain before opening.',
              'اس لنک میں مشکوک علامات موجود ہیں — کھولنے سے پہلے ڈومین کی تصدیق کریں۔',
              'هن لنڪ ۾ مشڪوڪ نشانيون موجود آهن — کولڻ کان اڳ ڊومين جي تصديق ڪريو.',
            )[language]
          : L(
              'Low structural risk detected based on URL inspection.',
              'لنک کی ساخت کے مطابق خطرہ کم ہے، تاہم ہمیشہ اصل ڈومین چیک کریں۔',
              'لنڪ جي بناوٽ موجب خطرو گهٽ آهي، تنهن هوندي به هميشه اصل ڊومين چيڪ ڪريو.',
            )[language];

    const recommendations =
      riskLevel === 'Low'
        ? [
            L(
              'Confirm the exact spelling of the university or government domain (.edu.pk / .gov.pk) in your browser.',
              'براؤزر میں یونیورسٹی یا سرکاری ڈومین (.edu.pk / .gov.pk) کے درست ہجے ضرور چیک کریں۔',
              'برائوزر ۾ يونيورسٽي يا سرڪاري ڊومين (.edu.pk / .gov.pk) جي صحيح هجي ضرور چيڪ ڪريو.',
            )[language],
            L(
              'Never enter your banking PIN, OTP, or password unless you navigated to the site yourself.',
              'جب تک آپ خود ویب سائٹ نہ کھولیں، کبھی اپنا بینک پن، او ٹی پی یا پاس ورڈ درج نہ کریں۔',
              'جيسيتائين توهان پاڻ ويب سائيٽ نه کوليو، ڪڏهن به پنهنجو بئنڪ پن، او ٽي پي يا پاسورڊ داخل نه ڪريو.',
            )[language],
          ]
        : [
            L(
              'Do NOT open this link or enter any personal details, CNIC, roll number, password, or OTP.',
              'اس لنک کو ہرگز نہ کھولیں اور نہ ہی شناختی کارڈ، رول نمبر، پاس ورڈ یا او ٹی پی درج کریں۔',
              'هن لنڪ کي هرگز نه کوليو ۽ نه ئي سڃاڻپ ڪارڊ، رول نمبر، پاسورڊ يا او ٽي پي داخل ڪريو.',
            )[language],
            L(
              'Verify scholarships, exam results, or fee notices directly via official .edu.pk or .gov.pk websites.',
              'اسکالرشپ، امتحانی نتائج یا فیس نوٹس کی تصدیق صرف سرکاری .edu.pk یا .gov.pk ویب سائٹس سے کریں۔',
              'اسڪالرشپ، امتحاني نتيجن يا فيس نوٽيس جي تصديق صرف سرڪاري .edu.pk يا .gov.pk ويب سائيٽن تان ڪريو.',
            )[language],
            L(
              'Block the sender and report phishing links to the FIA Cyber Crime Wing (Helpline 1991).',
              'بھیجنے والے کو بلاک کریں اور جعلی لنکس کی شکایت FIA سائبر کرائم ہیلپ لائن (1991) پر کریں۔',
              'موڪليندڙ کي بلاڪ ڪريو ۽ جعلي لنڪس جي شڪايت FIA سائبر ڪرائم هيلپ لائين (1991) تي ڪريو.',
            )[language],
          ];

    return {
      tool,
      language,
      riskLevel,
      summary,
      reasons,
      recommendations,
      engine: 'rule-based',
      fallbackNotice,
      containsSensitivePattern,
      urlDetails: d,
      analyzedAt,
    };
  }

  if (tool === 'cyberbullying') {
    const threatRegex =
      /(kill|hurt|beat|destroy|ruin your life|leak|viral|nude|blackmail|expose|dox|address|follow you|mar dunga|maar|badnam|tasveer|video viral|dhamki|دھمکی|جان سے|وائرل|بدنام|تصویر|بلیک میل|ڌمڪي|ماري|وائرل|بدنام|بليڪ ميل)/i;
    const insultRegex =
      /(stupid|idiot|ugly|loser|worthless|trash|hate you|shut up|pagal|kutta|kamina|ghatiya|bakwas|بکواس|گھٹیا|بیوقوف|پاگل|پاڳل|بيوقوف|گندو|بڪواس)/i;
    const coercionRegex =
      /(send money|pay me|send photo|send pic|do what i say|or else|varna|warna|ورنہ|پیسے بھیجو|تصویر بھیجو|پئسا موڪل|ناهي ته)/i;
    const selfHarmRegex =
      /(die|kill yourself|suicide|mar ja|مر جا|خودکشی|مري وڃ)/i;

    let score = 0;
    const reasons: string[] = [];

    if (threatRegex.test(text)) {
      score += 4;
      reasons.push(
        L(
          'Contains intimidation, blackmail, or threats to leak private media or cause harm.',
          'پیغام میں دھمکی، بلیک میلنگ، یا ذاتی تصاویر/ویڈیو وائرل کرنے کی کوشش شامل ہے۔',
          'پيغام ۾ ڌمڪي، بليڪ ميلنگ، يا ذاتي تصويرون/ويڊيو وائرل ڪرڻ جي ڪوشش شامل آهي.',
        )[language],
      );
    }
    if (coercionRegex.test(text)) {
      score += 4;
      reasons.push(
        L(
          'Shows signs of extortion or coercion demanding money, photos, or compliance under pressure.',
          'دباؤ ڈال کر پیسے، تصاویر یا غیر قانونی مطالبات منوانے کی کوشش کی علامات موجود ہیں۔',
          'دٻاءُ وجهي پئسا، تصويرون يا غير قانوني مطالبا مڃائڻ جي ڪوشش جا نشان موجود آهن.',
        )[language],
      );
    }
    if (selfHarmRegex.test(text)) {
      score += 5;
      reasons.push(
        L(
          'Includes severe harmful language encouraging self-harm or violence.',
          'اس میں شدید نقصان دہ یا خودکشی/تشدد پر اکسانے والے الفاظ موجود ہیں۔',
          'هن ۾ سخت نقصانڪار يا خودڪشي/تشدد تي اڀاريندڙ لفظ شامل آهن.',
        )[language],
      );
    }
    if (insultRegex.test(text)) {
      score += 2;
      reasons.push(
        L(
          'Contains derogatory insults, humiliation, or targeted verbal abuse.',
          'پیغام میں تضحیک آمیز الفاظ، توہین یا ذاتی حملے شامل ہیں۔',
          'پيغام ۾ توهين آميز لفظ، بيعزتي يا ذاتي حملا شامل آهن.',
        )[language],
      );
    }
    if ((text.match(/!/g) || []).length >= 3 || (text === text.toUpperCase() && text.length > 15)) {
      score += 1;
      reasons.push(
        L(
          'Uses aggressive formatting (repeated exclamation marks or all-caps shouting).',
          'جارحانہ انداز (بار بار فجائیہ نشانات یا بڑے حروف) استعمال کیا گیا ہے۔',
          'جارحاڻو انداز (بار بار عجب جون نشانيون يا وڏا اکر) استعمال ڪيو ويو آهي.',
        )[language],
      );
    }

    const riskLevel: RiskLevel =
      score >= 4 ? 'High' : score >= 2 ? 'Medium' : 'Low';

    if (reasons.length === 0) {
      reasons.push(
        L(
          'No explicit threats, extortion, or abusive harassment keywords were detected.',
          'اس پیغام میں واضح دھمکی، بلیک میلنگ یا ہراسانی کے الفاظ نہیں ملے۔',
          'هن پيغام ۾ واضح ڌمڪي، بليڪ ميلنگ يا هراسانيءَ جا لفظ نه مليا آهن.',
        )[language],
      );
    }

    const summary =
      riskLevel === 'High'
        ? L(
            'High-risk cyberbullying or harassment detected — take protective action immediately.',
            'شدید آن لائن ہراسانی یا بلیک میلنگ کی علامات — فوری حفاظتی اقدامات کریں۔',
            'شديد آن لائين هراساني يا بليڪ ميلنگ جون نشانيون — فوري حفاظتي قدم کڻو.',
          )[language]
        : riskLevel === 'Medium'
          ? L(
              'Potential verbal harassment or hostile language detected.',
              'ممکنہ آن لائن بدسلوکی یا ناگوار رویے کی علامات موجود ہیں۔',
              'ممڪنه آن لائين بدسلوڪي يا ناگوار رويي جون نشانيون موجود آهن.',
            )[language]
          : L(
              'Low risk of cyberbullying detected in this message.',
              'اس پیغام میں سائبر بلنگ یا ہراسانی کا خطرہ کم ہے۔',
              'هن پيغام ۾ سائبر بلنگ يا هراسانيءَ جو خطرو گهٽ آهي.',
            )[language];

    const recommendations =
      riskLevel === 'Low'
        ? [
            L(
              'If a conversation still makes you uncomfortable, you can mute or restrict the sender anytime.',
              'اگر کوئی گفتگو آپ کو غیر آرام دہ لگے تو آپ کسی بھی وقت بھیجنے والے کو میوٹ یا محدود کر سکتے ہیں۔',
              'جيڪڏهن ڪا ڳالهه ٻولهه توهان کي پريشان ڪري ته توهان ڪنهن به وقت موڪليندڙ کي ميوٽ يا محدود ڪري سگهو ٿا.',
            )[language],
          ]
        : [
            L(
              'Do NOT reply, argue, or pay anything to blackmailers — silence prevents escalation.',
              'بلیک میلر کو ہرگز جواب نہ دیں، بحث نہ کریں اور نہ ہی کوئی رقم بھیجیں۔',
              'بليڪ ميلر کي هرگز جواب نه ڏيو، بحث نه ڪريو ۽ نه ئي ڪا رقم موڪليو.',
            )[language],
            L(
              'Take clear screenshots (including username, profile link, and timestamps) as evidence before blocking.',
              'بلاک کرنے سے پہلے ثبوت کے طور پر صارف نام، پروفائل لنک اور وقت کے ساتھ اسکرین شاٹس محفوظ کریں۔',
              'بلاڪ ڪرڻ کان اڳ ثبوت طور يوزرنيم، پروفائل لنڪ ۽ وقت سميت اسڪرين شاٽس محفوظ ڪريو.',
            )[language],
            L(
              'Tell a trusted parent, teacher, or university counselor, and report to FIA Cyber Crime (1991) or DRF Helpline (0800-39393).',
              'اپنے والدین، استاد یا یونیورسٹی کونسلر کو بتائیں اور FIA (1991) یا DRF ہیلپ لائن (0800-39393) پر رپورٹ کریں۔',
              'پنهنجي والدين، استاد يا يونيورسٽي ڪائونسلر کي ٻڌايو ۽ FIA (1991) يا DRF هيلپ لائين (0800-39393) تي رپورٽ ڪريو.',
            )[language],
          ];

    return {
      tool,
      language,
      riskLevel,
      summary,
      reasons,
      recommendations,
      engine: 'rule-based',
      fallbackNotice,
      containsSensitivePattern,
      analyzedAt,
    };
  }

  let score = 0;
  const reasons: string[] = [];

  const otpRegex =
    /(otp|pin|mpin|verification code|4-digit|6-digit|secret code|پاس ورڈ|پن کوڈ|او ٹی پی|کوڈ بتائیں|پن ڪوڊ|او ٽي پي|ڪوڊ ٻڌايو)/i;
  const paymentRegex =
    /(easypaisa|jazzcash|sadapay|nayapay|bank account|atm|card block|account blocked|registration fee|processing fee|send rs|transfer|ایزی پیسہ|جاز کیش|اکاؤنٹ بلاک|فیس بھیجیں|ايزي پيسا|جاز ڪيش|اڪائونٽ بلاڪ|فيس موڪليو)/i;
  const lureRegex =
    /(congratulations|you won|lucky draw|lottery|prize|free laptop|scholarship|bisp|ehsaas|8171|benazir|mubarak|inam|انعام|مبارک|مفت لیپ ٹاپ|اسکالرشپ|بے نظیر|انعام|مبارڪ|مفت ليپ ٽاپ|اسڪالرشپ)/i;
  const urgencyRegex =
    /(urgent|immediately|within 24 hours|last chance|expire today|suspended|act now|legal action|فوری|آخری موقع|بند ہو جائے گا|فوري|آخري موقعو|بند ٿي ويندو)/i;
  const linkInMsg = /https?:\/\/[^\s]+|\b[a-z0-9-]+\.(xyz|tk|ml|top|click|club|info)\b/i;

  if (otpRegex.test(text)) {
    score += 4;
    reasons.push(
      L(
        'Asks for an OTP, MPIN, password, or verification code — legitimate banks and universities never ask for these.',
        'پیغام میں او ٹی پی، پن یا تصدیقی کوڈ مانگا جا رہا ہے — اصل بینک یا یونیورسٹیاں کبھی کوڈ نہیں مانگتیں۔',
        'پيغام ۾ او ٽي پي، پن يا تصديقي ڪوڊ گهريو پيو وڃي — اصل بئنڪ يا يونيورسٽيون ڪڏهن به ڪوڊ نه گهرنديون آهن.',
      )[language],
    );
  }
  if (paymentRegex.test(text)) {
    score += 3;
    reasons.push(
      L(
        'Mentions mobile wallets (Easypaisa/JazzCash), account suspension, or asks for an upfront processing/registration fee.',
        'موبائل والٹ (ایزی پیسہ/جاز کیش)، اکاؤنٹ بندش یا پیشگی فیس کی ادائیگی کا ذکر موجود ہے۔',
        'موبائل والٽ (ايزي پيسا/جاز ڪيش)، اڪائونٽ بند ٿيڻ يا اڳواٽ فيس موڪلڻ جو ذڪر موجود آهي.',
      )[language],
    );
  }
  if (lureRegex.test(text)) {
    score += 3;
    reasons.push(
      L(
        'Uses tempting prize, lottery, BISP/Ehsaas cash grant, or free scholarship/laptop lures common in student scams.',
        'انعام، لاٹری، بی آئی ایس پی/احساس امداد یا مفت اسکالرشپ/لیپ ٹاپ کا لالچ دیا گیا ہے جو طلبہ کے خلاف عام دھوکہ دہی ہے۔',
        'انعام، لاٽري، بي آءِ ايس پي/احساس امداد يا مفت اسڪالرشپ/ليپ ٽاپ جي لالچ ڏني وئي آهي.',
      )[language],
    );
  }
  if (urgencyRegex.test(text)) {
    score += 2;
    reasons.push(
      L(
        'Creates artificial urgency ("act now", "last chance", "account blocked today") to rush you into a mistake.',
        'جلد بازی اور خوف پیدا کرنے والے الفاظ ("فوری"، "آخری موقع") استعمال کیے گئے ہیں تاکہ آپ سوچ سمجھ کر فیصلہ نہ کر سکیں۔',
        'تڪڙ ۽ خوف پيدا ڪندڙ لفظ ("فوري"، "آخري موقعو") استعمال ڪيا ويا آهن ته جيئن توهان سوچي نه سگهو.',
      )[language],
    );
  }

  let urlDetails: UrlInspectionDetails | undefined;
  if (linkInMsg.test(text)) {
    const urlResult = inspectUrlStructure(text);
    if (urlResult.valid && urlResult.details) {
      urlDetails = urlResult.details;
      if (!urlResult.details.isOfficialPkDomain) {
        score += urlResult.details.hasSuspiciousTld || !urlResult.details.isHttps ? 3 : 2;
        reasons.push(
          L(
            `Includes an unverified external link (${urlResult.details.hostname}) rather than an official .edu.pk or .gov.pk domain.`,
            `پیغام میں سرکاری .edu.pk یا .gov.pk کے بجائے غیر تصدیق شدہ لنک (${urlResult.details.hostname}) شامل ہے۔`,
            `پيغام ۾ سرڪاري .edu.pk يا .gov.pk بدران غير تصديق ٿيل لنڪ (${urlResult.details.hostname}) شامل آهي.`,
          )[language],
        );
      }
    }
  }

  const riskLevel: RiskLevel =
    score >= 5 ? 'High' : score >= 2 ? 'Medium' : 'Low';

  if (reasons.length === 0) {
    reasons.push(
      L(
        'No common scam triggers (OTP requests, fake prizes, urgency threats, or suspicious links) were detected.',
        'اس پیغام میں عام فراڈ کی علامات (او ٹی پی کا مطالبہ، جعلی انعام، دھمکی یا مشکوک لنک) نہیں ملیں۔',
        'هن پيغام ۾ عام دوکي جون نشانيون (او ٽي پي جي گهر، جعلي انعام، ڌمڪي يا مشڪوڪ لنڪ) نه مليون آهن.',
      )[language],
    );
  }

  const summary =
    riskLevel === 'High'
      ? L(
          'High-risk scam pattern detected — likely phishing or financial fraud.',
          'زیادہ خطرہ: یہ پیغام غالباً مالی فراڈ یا فشنگ اسکیم ہے۔',
          'وڌيڪ خطرو: هي پيغام گهڻو ڪري مالي دوکو يا فشنگ اسڪيم آهي.',
        )[language]
      : riskLevel === 'Medium'
        ? L(
            'Suspicious elements detected — verify through official channels before responding.',
            'مشکوک علامات موجود ہیں — جواب دینے سے پہلے سرکاری ذرائع سے تصدیق کریں۔',
            'مشڪوڪ نشانيون موجود آهن — جواب ڏيڻ کان اڳ سرڪاري ذريعن کان تصديق ڪريو.',
          )[language]
        : L(
            'Low scam risk detected — always stay cautious with unknown senders.',
            'فراڈ کا خطرہ کم ہے، تاہم نامعلوم نمبروں کے ساتھ ہمیشہ محتاط رہیں۔',
            'دوکي جو خطرو گهٽ آهي، پر اڻڄاتل نمبرن سان هميشه محتاط رهو.',
          )[language];

  const recommendations =
    riskLevel === 'Low'
      ? [
          L(
            'Confirm the sender identity independently if the message asks you to take any action.',
            'اگر پیغام میں کوئی عمل کرنے کو کہا گیا ہو تو بھیجنے والے کی شناخت کی الگ سے تصدیق کریں۔',
            'جيڪڏهن پيغام ۾ ڪو عمل ڪرڻ لاءِ چيو ويو هجي ته موڪليندڙ جي سڃاڻپ جي الڳ تصديق ڪريو.',
          )[language],
          L(
            'Never share OTPs, passwords, or CNIC photos over SMS or WhatsApp.',
            'کبھی بھی ایس ایم ایس یا واٹس ایپ پر او ٹی پی، پاس ورڈ یا شناختی کارڈ کی تصویر شیئر نہ کریں۔',
            'ڪڏهن به ايس ايم ايس يا واٽس ايپ تي او ٽي پي، پاسورڊ يا سڃاڻپ ڪارڊ جي تصوير شيئر نه ڪريو.',
          )[language],
        ]
      : [
          L(
            'Do NOT reply, call back the unknown number, or share any OTP, Easypaisa/JazzCash PIN, or CNIC.',
            'جواب نہ دیں، نامعلوم نمبر پر کال نہ کریں، اور کبھی او ٹی پی، ایزی پیسہ/جاز کیش پن یا شناختی کارڈ نہ بتائیں۔',
            'جواب نه ڏيو، اڻڄاتل نمبر تي ڪال نه ڪريو، ۽ ڪڏهن به او ٽي پي، ايزي پيسا/جاز ڪيش پن يا سڃاڻپ ڪارڊ نه ٻڌايو.',
          )[language],
          L(
            'Verify scholarship or university notices directly on official .edu.pk or .gov.pk portals (or 8171 official BISP channel).',
            'اسکالرشپ یا یونیورسٹی نوٹس کی تصدیق صرف سرکاری .edu.pk یا .gov.pk ویب سائٹس (یا سرکاری 8171) سے کریں۔',
            'اسڪالرشپ يا يونيورسٽي نوٽيس جي تصديق صرف سرڪاري .edu.pk يا .gov.pk ويب سائيٽن تان ڪريو.',
          )[language],
          L(
            'Delete the message, block the sender, and report cyber scams to FIA Cyber Crime Wing at 1991.',
            'پیغام حذف کریں، نمبر بلاک کریں اور ایف آئی اے سائبر کرائم ہیلپ لائن 1991 پر شکایت درج کرائیں۔',
            'پيغام ڊليٽ ڪريو، نمبر بلاڪ ڪريو ۽ ايف آءِ اي سائبر ڪرائم هيلپ لائين 1991 تي شڪايت داخل ڪرايو.',
          )[language],
        ];

  return {
    tool,
    language,
    riskLevel,
    summary,
    reasons,
    recommendations,
    engine: 'rule-based',
    fallbackNotice,
    containsSensitivePattern,
    urlDetails,
    analyzedAt,
  };
}
