export type Language = 'en' | 'ur' | 'sd';

export type ToolType = 'scam' | 'link' | 'cyberbullying';

export type ActiveView =
  | 'dashboard'
  | 'scam'
  | 'link'
  | 'cyberbullying'
  | 'tips'
  | 'about';

export type RiskLevel = 'Low' | 'Medium' | 'High';

export interface UrlInspectionDetails {
  normalizedUrl: string;
  protocol: string;
  hostname: string;
  tld: string;
  isHttps: boolean;
  isOfficialPkDomain: boolean;
  isShortener: boolean;
  hasIpHost: boolean;
  hasSuspiciousTld: boolean;
  subdomainCount: number;
  flaggedKeywords: string[];
}

export interface AnalysisResult {
  tool: ToolType;
  language: Language;
  riskLevel: RiskLevel;
  summary: string;
  reasons: string[];
  recommendations: string[];
  engine: 'gemini' | 'rule-based';
  fallbackNotice?: string;
  containsSensitivePattern?: boolean;
  urlDetails?: UrlInspectionDetails;
  analyzedAt: string;
}

export interface SessionScanItem {
  id: string;
  tool: ToolType;
  preview: string;
  riskLevel: RiskLevel;
  engine: 'gemini' | 'rule-based';
  timestamp: string;
  result: AnalysisResult;
}
